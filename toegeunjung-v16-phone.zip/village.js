/* 퇴근중 · 돌마을 = 돌대리 회사 2층 (v13)
   3D로 미리 렌더링한 사무실 층 이미지(office-day.jpg / office-night.jpg) 위를 걸어 다녀요.
   좌표는 360 × 376 지도 단위이고, 3D 장면에서 문·간판·복도 위치를 그대로 뽑아 왔어요 (tools 쪽 office.html).
   door = 들어가기가 뜨는 문 앞 / hit = 누르면 그 방으로 걸어가는 영역 / lab = 이름 간판 위치 / WALK = 걸을 수 있는 복도 */
(function(){
"use strict";
const W=360,H=376;
const PLACES=[{"id": "work", "kind": "work", "emoji": "💻", "name": "업무존", "door": {"x": 165.7, "y": 134.2}, "lab": {"x": 88.6, "y": 46.7}, "hit": {"x": 21.4, "y": 54.7, "w": 134.3, "h": 102.6}}, {"id": "meeting", "kind": "space", "emoji": "🪑", "name": "회의실", "door": {"x": 194.3, "y": 134.2}, "lab": {"x": 271.4, "y": 46.7}, "hit": {"x": 204.3, "y": 54.7, "w": 134.3, "h": 102.6}}, {"id": "pantry", "kind": "space", "emoji": "☕", "name": "탕비실", "door": {"x": 165.7, "y": 215.9}, "lab": {"x": 88.6, "y": 128.4}, "hit": {"x": 21.4, "y": 136.4, "w": 134.3, "h": 102.6}}, {"id": "cafeteria", "kind": "space", "emoji": "🍚", "name": "구내식당", "door": {"x": 194.3, "y": 215.9}, "lab": {"x": 271.4, "y": 128.4}, "hit": {"x": 204.3, "y": 136.4, "w": 134.3, "h": 102.6}}, {"id": "toilet", "kind": "space", "emoji": "🚽", "name": "화장실", "door": {"x": 165.7, "y": 297.6}, "lab": {"x": 88.6, "y": 210.1}, "hit": {"x": 21.4, "y": 218.1, "w": 134.3, "h": 102.6}}, {"id": "pond", "kind": "fish", "emoji": "🎣", "name": "휴게 정원", "door": {"x": 194.3, "y": 297.6}, "lab": {"x": 271.4, "y": 210.1}, "hit": {"x": 204.3, "y": 218.1, "w": 134.3, "h": 102.6}}, {"id": "commute", "kind": "space", "emoji": "🛗", "name": "퇴근 엘리베이터", "door": {"x": 180, "y": 94.9}, "lab": {"x": 180, "y": 20.3}, "hit": {"x": 147.1, "y": 28.3, "w": 65.8, "h": 60.6}}, {"id": "board", "kind": "board", "emoji": "📋", "name": "마을 게시판", "door": {"x": 180, "y": 326.2}, "lab": {"x": 180, "y": 292}, "hit": {"x": 154.3, "y": 300, "w": 51.4, "h": 42.7}}];
const WALK=[{"x": 162.9, "y": 92.1, "w": 34.2, "h": 237.7}, {"x": 28.6, "y": 159.6, "w": 302.8, "h": 9.2}, {"x": 28.6, "y": 241.3, "w": 302.8, "h": 9.2}];
const SPAWN={"x": 180, "y": 269.7};
const BOUNDS={x0:0,x1:W,y0:0,y1:H};
function svg(hour){hour=hour==null?new Date().getHours():hour;const night=hour>=19||hour<6;
 return `<img class="vmap" src="office-${night?"night":"day"}.jpg" alt="" draggable="false">`}
window.TG_VILLAGE={W,H,PLACES,SPAWN,BOUNDS,WALK,svg};
})();
